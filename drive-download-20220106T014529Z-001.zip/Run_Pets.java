package Week6_003;

public class Run_Pets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Inheritance - reusing code and data from other classes
		// Hierarchy - super class that provides code/data that can be use in
		// sub classes 
		
	
		Pets pet1 = new Pets(500, 1500 , 12); 
	
		System.out.println(pet1.getClass().getName() + "" + pet1.getTotCost());
		Dogs dog2 = new Dogs("terrier"); 
		dog2.setAllCost(300, 1000 , 15); 
		System.out.println(dog2.getClass().getName() + " " + dog2.getBreed()) ; 
		System.out.println(" " + dog2.getTotCost()); 
	
		Dogs dog3 = new Dogs("german shepard", 1000, 2000, 10); 
		System.out.println(dog2.getClass().getName() + " " + dog2.getBreed()) ; 
		System.out.println(" " + dog2.getTotCost()); 
	
		Cats cat4 = new Cats("persian" , 200, 233, 20); 
		
	}

}

class Pets {
	
	private double purchCost; // total cost of ownership
	private double maintCost;
	private double lifeSpan; // use the vars to calc to calc tot cost of ownership
	 
	Pets() {} 
	Pets(double purchCost, double maintCost, double lifespan) {
		this.purchCost = purchCost; 
		this.maintCost = maintCost;
		this.lifeSpan = lifespan; 
		
	}
	public void setAllCost(double purchCost, double maintCost, double lifespan) {
		this.purchCost = purchCost;
		this.lifeSpan = lifespan; 
		this.maintCost = maintCost; 
	}
	
	public double getTotCost() { 
		return purchCost + (maintCost * lifeSpan);
		
	}
}
class Dogs extends Pets{
	private String breed;
	
	Dogs(String breed){
		this.breed = breed; 
	}
	
	Dogs(String breed, double purchCost, double maintCost, double lifespan) {
		super(purchCost,maintCost, lifespan); // has to be the first line in the constructor 
		this.breed = breed; 
	}
	
	public String getBreed() {
		
	return breed; 
	}
	
}
class Cats {
	
	private String breed;
	
	Cats() {} 
	Cats(String breed) { 
		this.breed = breed; 
		
	)
	}
	Cats(string breed, double purchCost, double maintCost, double lifespan) {
		super(purchCost,maintCost, lifespan); 
		this.breed = breed; 
	}
	
	
}