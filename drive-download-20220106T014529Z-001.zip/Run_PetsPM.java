package week_6;

 

public class Run_PetsPM {

 

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        // Polymorphism
    	
    	 PetsPM pet1 = new PetsPM(); 
    	 pet1.getSound(); 
    	 pet1.setWeight(34); 
    	 System.out.println(pet1 +pet1.getWeight() + " " + pet1.getBig()); 
    	 
    	 DogsPM dog2 = new DogsPM(); 
    	 
    	 dog2.getSounds(); 
    	 
    	 
    	 PetsPM1 
        
        Pets pet1 = new Pets(500, 1500, 12);        
        System.out.println(pet1.getClass().getName() + " " + pet1.getTotCost());
        
        Dogs dog2 = new Dogs("terrier");
        dog2.setAllCost(300, 1000, 15);
        System.out.print(dog2.getClass().getName() + " " + dog2.getBreed());
        System.out.println(" " + dog2.getTotCost());
        
        Dogs dog3 = new Dogs("german shephard", 1000, 2000, 10);
        System.out.print(dog3.getClass().getName() + " " + dog3.getBreed());
        System.out.println(" " + dog3.getTotCost());
        
        Cats cat4 = new Cats("persian", 200, 600, 20);
        System.out.print(cat4.getClass().getName() + " " + cat4.getBreed());
        System.out.println(" " + cat4.getTotCost());
}

 


class PetsPM {
    private double purchCost;    // one-time cost to acquire pet
    private double maintCost;    // est. annual cost to keep pet
    private double lifespan; // use the vars to calculate TCO (total cost of ownership)
    private double weight; // record the weight of the pet 
    private boolean big; // this var will indicate if the pet is big or not
    
    
    
    
    PetsPM(){}
    PetsPM(double purchCost, double maintCost, double lifespan){
        this.purchCost = purchCost;
        this.maintCost = maintCost;
        this.lifespan = lifespan;
    }
    
    public void setAllCost(double purchCost, double maintCost, double lifespan) {
        this.purchCost = purchCost;
        this.maintCost = maintCost;
        this.lifespan = lifespan;
    }
    
    public double getTotCost() {
        return purchCost + (maintCost * lifespan);
    }
    
    public void getSound() {
    	System.out.print("all pets make sound");
    	
    }
}

 

class DogsPM extends PetsPM{
    private String breed;
    
    DogsPM () {} 
   
    DogsPM(String breed){
        this.breed = breed;
    }
    
    DogsPM(String breed, double purchCost, double maintCost, double lifespan){
        super(purchCost, maintCost, lifespan);
        this.breed = breed;
    }
    
    public String getBreed() {
        return breed;
    }    
}

public void getSounds() {
	System.out.println("dogs bark"); 
}

 

class CatsPM extends PetsPM{
    private String breed;
    
    CatsPM() {}
    CatsPM(String breed){
        this.breed = breed;
    }
    CatsPM(String breed, double purchCost, double maintCost, double lifespan){
        super(purchCost, maintCost, lifespan);
        this.breed = breed;
    }
    
    public String getBreed() {
        return breed;
    }    
    
    public void getSound() {
    	System.out.println(); 
    }
    
    public void setWeight(double weight) {
    	this.setWeight = weight;  
    	
    }
}



