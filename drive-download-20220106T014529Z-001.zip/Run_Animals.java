package Week6_003;

public class Run_Animals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

class Animals {
	
}
class Pets extends Animals {
	
} 
class Dogs extends Pets {
	
}
